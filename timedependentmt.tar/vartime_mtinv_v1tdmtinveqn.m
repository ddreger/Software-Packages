%Routine to invert for a time variable MT, Green's functions
%computed with Robert Herrmann's Computer Programs for Seismology package
%Native convention is Langston 1981 - need to multiply MT by -1 to have AKI
%%Mxx, Mxy etc from Minson and Dreger

clear all;
close all;
 
%input parameters
tshift=5.3;  %start time of data no shift needs to be set to dt
len=34.0;     %length of data to use
numwin=23;     %number of time windows Preferred: 23 1.0
halfw=1.0;     %half width of applied triangular source (sec)
weight=1.0e-5;  %weight for temporal smoothing 4.0e-4

%Read input file for data and Green's function information
[n, names, gfnames, tadj, azi, wz, wr, wt]=textread('statlist.txt','%d %s %s %f %f %f %f %f');
nstat=max(n);
% 
Ndata=0
for STAT=1:nstat

[dataz, hd]=rdSac(strcat(names{STAT},'_ehz'));
[datar, hd]=rdSac(strcat(names{STAT},'_ehr'));
[datat, hd]=rdSac(strcat(names{STAT},'_eht'));
hd=rdSacHead(strcat(names{STAT},'_ehz'));
hd.delta;
nyquist=1/(2*hd.delta);

% n=length(dataz);
% noise=rand(3,n);
% noise=noise./(max(max(noise))).*1e-4;
% dataz=noise(1,:)';
% datar=noise(2,:)';
% datat=noise(3,:)';

% 
% %Note this block performs filtering. The butter command generates the
% %bandpass butterworth. The commented line for filtb and filta computes the
% %IIR filter which works for low order using filter and filtfilt. For higher
% %order this becomes unstable and a FIR filter is needed. The z,p,k
% %computer the zeros and poles for a FIR filter. the FIR description works
% %with filter, but not filtfilt (zero phase).
% 
% These corners also provide a good fit. The low corner is more consistent
% with SNR and the upper corner as well, however it is close to the second
% microseismic peak.The results are overall nearly the same as using the
% corners below in the initial analysis.
wl=0.25/nyquist; 
wh=0.50/nyquist;
n=3;
[filtb,filta]=butter(n,[wl wh],'bandpass');
[z, p, k]=butter(n,[wl wh],'bandpass'); %create zero pole response
[s,g]=zp2sos(z,p,k); %create second order sections
Hd=dfilt.df2sos(s,g); %create dfilt object

dataz=filter(Hd,dataz).*wz(STAT); %wz is a component weight use/don't use
datar=filter(Hd,datar).*wr(STAT);
datat=filter(Hd,datat).*wt(STAT);
% 
% %cut data for origin time shift
cut1=round((tshift+tadj(STAT))/hd.delta);
cut2=cut1 + round(len/hd.delta);
dataz=dataz(cut1:cut2);
datar=datar(cut1:cut2);
datat=datat(cut1:cut2);
Ndata=Ndata + nnz(dataz)+nnz(datar)+nnz(datat); % total data for Ftest
%Compute post filter and cut rms
rmswz(STAT)=sqrt(mean(dataz.^2));
rmswr(STAT)=sqrt(mean(datar.^2));
rmswt(STAT)=sqrt(mean(datat.^2));

%write data sacfiles
N=length(dataz);
tstart=0.;
MYJH_hd = newSacHeader(N,hd.delta,tstart);
dname=strcat(names{STAT},'_ehz_dat');
wtSac(dname,MYJH_hd,dataz);
dname=strcat(names{STAT},'_ehr_dat');
wtSac(dname,MYJH_hd,datar);
dname=strcat(names{STAT},'_eht_dat');
wtSac(dname,MYJH_hd,datat);


if (STAT == 1)
    DATA=[datat; datar; dataz];
end
if (STAT > 1)
    DATA=vertcat(DATA,[datat; datar; dataz]);
end

%load Green's Function
M0def=1.0e20; %default unit of force from Herrmann code units of dyne cm
filename=gfnames{STAT};
[jnk, npts, dt]=textread(filename,'%s %d %f',1);

temp=load(filename);
tss=temp(:,1);
tds=temp(:,2);
rss=temp(:,3);
rds=temp(:,4);
rdd=temp(:,5);
zss=temp(:,6);
zds=temp(:,7);
zdd=temp(:,8);
rex=temp(:,9);
zex=temp(:,10);

%%Need to flip verticals as in tdmt
rex=-1.*rex;
zss=-1.*zss;
zds=-1.*zds;
zdd=-1.*zdd;
zex=-1.*zex;
%clear temp;
% 


%construct basic triangular source
stime=0:dt:2*halfw;
tri=triangularPulse(0., halfw, 2*halfw, stime);
%tri=triangularPulse(0., halfw/2, 2*halfw/2, stime./2); %divide halfw, 2*halfw, stime by 2 to have non-overlapping
area=trapz(tri)*dt;
tri=tri./area;
areatest=trapz(tri)*dt


%construct GF with basic source convolved
N=length(tss);
tss=conv(tss,tri).*dt;
tds=conv(tds,tri).*dt;
rss=conv(rss,tri).*dt;
rds=conv(rds,tri).*dt;
rdd=conv(rdd,tri).*dt;
zss=conv(zss,tri).*dt;
zds=conv(zds,tri).*dt;
zdd=conv(zdd,tri).*dt;
rex=conv(rex,tri).*dt;
zex=conv(zex,tri).*dt;
tss=tss(1:N);
tds=tds(1:N);
rss=rss(1:N);
rds=rds(1:N);
rdd=rdd(1:N);
zss=zss(1:N);
zds=zds(1:N);
zdd=zdd(1:N);
rex=rex(1:N);
zex=zex(1:N);
tss=filter(Hd,tss);
tds=filter(Hd,tds);
rss=filter(Hd,rss);
rds=filter(Hd,rds);
rdd=filter(Hd,rdd);
zss=filter(Hd,zss);
zds=filter(Hd,zds);
zdd=filter(Hd,zdd);
rex=filter(Hd,rex);
zex=filter(Hd,zex);
tss(length(dataz)+1:end)=[];  %truncate Green's function to length of comparison
tds(length(dataz)+1:end)=[];
rss(length(dataz)+1:end)=[];
rds(length(dataz)+1:end)=[];
rdd(length(dataz)+1:end)=[];
zss(length(dataz)+1:end)=[];
zds(length(dataz)+1:end)=[];
zdd(length(dataz)+1:end)=[];
rex(length(dataz)+1:end)=[];
zex(length(dataz)+1:end)=[];

phi=azi(STAT)*pi/180.0;
A=0.5*sin(2*phi).*tss.*wt(STAT); %Mxx
B=(-0.5*cos(2*phi).*rss + rdd./6 + rex./3).*wr(STAT);
C=(-0.5*cos(2*phi).*zss + zdd./6 + zex./3).*wz(STAT);
D=-0.5*sin(2*phi).*tss.*wt(STAT); %Myy
E=(0.5*cos(2*phi).*rss + rdd./6 + rex./3).*wr(STAT);
F=(0.5*cos(2*phi).*zss + zdd./6 + zex./3).*wz(STAT);
G=0.*D; %Mzz - there is no transverse mzz component
H=(-1.*rdd./3 + rex./3).*wr(STAT);
I=(-1.*zdd./3 + zex./3).*wz(STAT);
J=-1.*tss.*cos(2*phi).*wt(STAT); %Mxy
K=-1.*rss.*sin(2*phi).*wr(STAT);
L=-1.*zss.*sin(2*phi).*wz(STAT);
M=-1.*tds.*sin(phi).*wt(STAT);        %Mxz
N=rds.*cos(phi).*wr(STAT);
O=zds.*cos(phi).*wz(STAT);
P=tds.*cos(phi).*wt(STAT);  %Myz
Q=rds.*sin(phi).*wr(STAT);
R=zds.*sin(phi).*wz(STAT);

mxxgf=[A; B; C];
myygf=[D; E; F];
mzzgf=[G; H; I];
mxygf=[J; K; L];
mxzgf=[M; N; O];
myzgf=[P; Q; R];

hfw=round(halfw/dt);
solntimebase=(0:1:numwin).*halfw;
if (numwin ~= 0)
  for j=1:numwin
  AA=[zeros(j*hfw,1); A(1:length(dataz)-j*hfw)];
  BB=[zeros(j*hfw,1); B(1:length(dataz)-j*hfw)];
  CC=[zeros(j*hfw,1); C(1:length(dataz)-j*hfw)];
  DD=[zeros(j*hfw,1); D(1:length(dataz)-j*hfw)];
  EE=[zeros(j*hfw,1); E(1:length(dataz)-j*hfw)];
  FF=[zeros(j*hfw,1); F(1:length(dataz)-j*hfw)];
  GG=[zeros(j*hfw,1); G(1:length(dataz)-j*hfw)];
  HH=[zeros(j*hfw,1); H(1:length(dataz)-j*hfw)];
  II=[zeros(j*hfw,1); I(1:length(dataz)-j*hfw)];
  JJ=[zeros(j*hfw,1); J(1:length(dataz)-j*hfw)];
  KK=[zeros(j*hfw,1); K(1:length(dataz)-j*hfw)];
  LL=[zeros(j*hfw,1); L(1:length(dataz)-j*hfw)];
  MM=[zeros(j*hfw,1); M(1:length(dataz)-j*hfw)];
  NN=[zeros(j*hfw,1); N(1:length(dataz)-j*hfw)];
  OO=[zeros(j*hfw,1); O(1:length(dataz)-j*hfw)];
  PP=[zeros(j*hfw,1); P(1:length(dataz)-j*hfw)];
  QQ=[zeros(j*hfw,1); Q(1:length(dataz)-j*hfw)];
  RR=[zeros(j*hfw,1); R(1:length(dataz)-j*hfw)];
  mxxgf=horzcat(mxxgf, [AA; BB; CC]); 
  myygf=horzcat(myygf, [DD; EE; FF]); 
  mzzgf=horzcat(mzzgf, [GG; HH; II]);
  mxygf=horzcat(mxygf, [JJ; KK; LL]);
  mxzgf=horzcat(mxzgf, [MM; NN; OO]);
  myzgf=horzcat(myzgf, [PP; QQ; RR]);

  end
end
% 
%clear A B C D E F G H I J K L M N O P Q R
%clear AA BB CC DD EE FF GG HH II JJ KK LL MM NN OO PP QQ RR;
% 
%construct Green's function matrix
if (STAT == 1 )
    GF=[mxxgf myygf mzzgf mxygf mxzgf myzgf];
end
if (STAT > 1)
    GF=vertcat(GF,[mxxgf myygf mzzgf mxygf mxzgf myzgf]);
end


end %End of Station Loop
% 
% 
% % %apply first-derivative smoothing constraint;
if(numwin ~= 0)
A=zeros(1,(numwin+1)*6); %zero constraint for number of windows x 3 components
B=zeros(1,(numwin+1)*6); %zero constraint for number of windows x 3 components
C=zeros(1,(numwin+1)*6); %zero constraint for number of windows x 3 components
D=zeros(1,(numwin+1)*6);
E=zeros(1,(numwin+1)*6);
F=zeros(1,(numwin+1)*6);
for i=1:numwin
    A(i,i)=weight;
    A(i,i+1)=-weight;
    B(i,i+(numwin+1))=weight;
    B(i,i+(numwin+1)+1)=-weight;
    C(i,i+2*(numwin+1))=weight;
    C(i,i+2*(numwin+1)+1)=-weight;
    D(i,i+3*(numwin+1))=weight;
    D(i,i+3*(numwin+1)+1)=-weight;
    E(i,i+4*(numwin+1))=weight;
    E(i,i+4*(numwin+1)+1)=-weight;
    F(i,i+5*(numwin+1))=weight;
    F(i,i+5*(numwin+1)+1)=-weight;
end
GF=vertcat(GF,A,B,C,D,E,F);
DATA=vertcat(DATA,zeros(6*numwin,1));
end
% 
%
Ainv=inv(GF'*GF);
%load data.mat
dd=GF'*DATA;
soln=(Ainv*dd)';

%This is to save a solution for jackknife subsitution test
%save soln.mat soln
%save data.mat DATA


%read previous solution for jackknife substitution test
%load soln.mat
syn=GF*soln';   %compute synthetic


DATA=DATA(1:length(DATA)-6*numwin); %remove constraining eqn parts
syn=syn(1:length(syn)-6*numwin);

M=reshape(soln,numwin+1,6);

VR=(1-sum((DATA-syn).^2)/sum(DATA.^2))*100

% % plot data and synthetic
N=length(dataz);
tbase=(0:1:N-1).*hd.delta;
n=1;  %counter
for STAT=1:nstat
    m=n+N-1;
    datat=DATA(n:m);
    synt=syn(n:n+N-1);
    n=m+1;
    m=n+N-1;
    datar=DATA(n:n+N-1);
    synr=syn(n:n+N-1);
    n=m+1;
    m=n+N-1;
    dataz=DATA(n:n+N-1);
    synz=syn(n:n+N-1);
    n=m+1;

    %Compute station specific VR
    statVR=(1-sum((vertcat(datar,datat,dataz)-vertcat(synr,synt,synz)).^2)/sum((vertcat(datar,datat,dataz)).^2))*100;
    fprintf('station=%s  VarRed=%.2f\n',names{STAT},statVR);

    figure;
    subplot(3,1,1);
    plot(tbase,datat,tbase,synt);
    titletxt=sprintf('station=%s: azi=%.1f transverse', names{STAT}, azi(STAT)');
    title(titletxt);
    subplot(3,1,2);
    plot(tbase,datar,tbase,synr);
    title('radial');
    ylabel('centimeters');
    subplot(3,1,3);
    plot(tbase,dataz,tbase,synz);
    title('vertical');
    xlabel('seconds');
end

%One plot of synthetic and data
figure;
n=1;
pcnt=1;
mamp=max(abs(DATA))
for STAT=1:nstat
    m=n+N-1;
    datat=DATA(n:m);
    synt=syn(n:n+N-1);
    n=m+1;
    m=n+N-1;
    datar=DATA(n:n+N-1);
    synr=syn(n:n+N-1);
    n=m+1;
    m=n+N-1;
    dataz=DATA(n:n+N-1);
    synz=syn(n:n+N-1);
    n=m+1;

    subplot(nstat,3,pcnt);
    plot(tbase,dataz,tbase,synz);
    ylim([-mamp mamp]);
    titletxt=sprintf('%s %.1f', names{STAT}, azi(STAT));
    title(titletxt);
    pcnt=pcnt+1;
    subplot(nstat,3,pcnt);
    plot(tbase,datar,tbase,synr);
    ylim([-mamp mamp]);
    pcnt=pcnt+1;
    subplot(nstat,3,pcnt);
    plot(tbase,datat,tbase,synt);
    ylim([-mamp mamp]);
    pcnt=pcnt+1;
end

%write synthetic sacfiles
N=length(dataz);
START=1;
END=N;
tstart=0.;
MYJH_hd = newSacHeader(N,dt,tstart);
for STAT=1:nstat
    synth=syn(START:END);
    sname=strcat(names{STAT},'_eht_syn');
    wtSac(sname,MYJH_hd,synth);
    START=START+N;
    END=END+N;
    synth=syn(START:END);
    sname=strcat(names{STAT},'_ehr_syn');
    wtSac(sname,MYJH_hd,synth);
    START=START+N;
    END=END+N;
    synth=syn(START:END);
    sname=strcat(names{STAT},'_ehz_syn');
    wtSac(sname,MYJH_hd,synth);
    START=START+N;
    END=END+N;
end


[nr nc]=size(M);
[numsol, numele]=size(M);
maxamp=max(max(abs(M)));
minamp=-1*maxamp;
if(numwin ~=0)
figure;
tbase2=(0:1:numsol-1).*halfw;
nr=max(tbase2);
subplot(6,1,1);
plot(tbase2,M(:,1));
title('Mxx');
axis([0 nr minamp maxamp]);
subplot(6,1,2);
plot(tbase2,M(:,2));
title('Myy');
axis([0 nr minamp maxamp]);
subplot(6,1,3);
plot(tbase2,M(:,3));
title('Mzz');
axis([0 nr minamp maxamp]);
subplot(6,1,4);
plot(tbase2,M(:,4));
title('Mxy');
ylabel('Moment Rate');
axis([0 nr minamp maxamp]);
subplot(6,1,5);
plot(tbase2,M(:,5));
title('Mxz');
axis([0 nr minamp maxamp]);
subplot(6,1,6);
plot(tbase2,M(:,6));
title('Myz');
axis([0 nr minamp maxamp]);
end

for i=1:numsol
    junk=[M(i,1) M(i,4) M(i,5); M(i,4) M(i,2) M(i,6); M(i,5) M(i,6) M(i,3)];
    isomo=(M(i,1) + M(i,2) + M(i,3))/3;
    junk=junk-isomo.*eye(3);
    mdev=max(abs(eigs(junk)));
    MO(i)=abs(isomo) + mdev;
    
%     MO(i)=norm(junk,"fro");
    Miso(i)=-1*isomo; %sign is for Aki convention for plotting
end
figure;
plot((0:1:numsol-1).*halfw,MO);
xlabel('Time (s)');
ylabel('Isotropic Scalar Moment');
figure;
plot((0:1:numsol-1).*halfw,Miso./MO*100);
xlabel('Time (s)');
ylabel('% of Total Moment');
totalMO=sum(MO)

%Compute Eigenvalues and Eigenvectors
fdo=fopen('lambda.out','w');
fdo2=fopen('moment_tensor.out','w');
for i=1:numsol
[V,D] = eig([M(i,1) M(i,4) M(i,5); M(i,4) M(i,2) M(i,6); M(i,5) M(i,6) M(i,3)]);
lam(i,1)=-1*D(1,1); %output to AKI convention
lam(i,2)=-1*D(2,2);
lam(i,3)=-1*D(3,3);
fprintf(fdo,'%f %f %f\n',-1*D(1,1), -1*D(2,2), -1*D(3,3));
fprintf(fdo2,'%f %f %f %f %f %f\n',-1*M(i,1),-1*M(i,2),-1*M(i,3),-1*M(i,4),-1*M(i,5),-1*M(i,6));
end
fclose(fdo);
fclose(fdo2);


I=1;
fprintf('Particular MT in Aki convention\n');
fprintf('Mxx=%E\n',-1*M(I,1));
fprintf('Myy=%E\n',-1*M(I,2));
fprintf('Mzz=%E\n',-1*M(I,3));
fprintf('Mxy=%E\n',-1*M(I,4));
fprintf('Mxz=%E\n',-1*M(I,5));
fprintf('Myz=%E\n\n',-1*M(I,6));

fprintf('Composite MT in Aki convention\n');
fprintf('Mxx=%E\n',-1*sum(M(:,1)));
fprintf('Myy=%E\n',-1*sum(M(:,2)));
fprintf('Mzz=%E\n',-1*sum(M(:,3)));
fprintf('Mxy=%E\n',-1*sum(M(:,4)));
fprintf('Mxz=%E\n',-1*sum(M(:,5)));
fprintf('Myz=%E\n',-1*sum(M(:,6)));

fprintf('Ndata=%d\n',Ndata);

